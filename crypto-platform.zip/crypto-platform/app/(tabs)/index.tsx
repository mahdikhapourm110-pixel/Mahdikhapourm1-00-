import { useCallback, useState } from "react";
import { View, Text, FlatList, RefreshControl, StyleSheet, TouchableOpacity } from "react-native";
import { useFocusEffect } from "expo-router";
import { getWallets, getApiKeys, WalletEntry } from "../../src/lib/storage";
import { fetchAllBalances, WalletBalanceRow } from "../../src/lib/assets";

export default function AssetsScreen() {
  const [wallets, setWallets] = useState<WalletEntry[]>([]);
  const [rows, setRows] = useState<WalletBalanceRow[]>([]);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [w, keys] = await Promise.all([getWallets(), getApiKeys()]);
      setWallets(w);
      const balances = await fetchAllBalances(w, keys);
      setRows(balances);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const totalUsd = rows.reduce(
    (sum, row) => sum + row.lines.reduce((s, line) => s + (line.usdValue ?? 0), 0),
    0
  );

  return (
    <View style={styles.container}>
      {wallets.length === 0 && !loading && (
        <View style={styles.empty}>
          <Text style={styles.emptyText}>هنوز آدرسی اضافه نکردی. از تب تنظیمات یک کیف‌پول اضافه کن.</Text>
        </View>
      )}
      {rows.length > 0 && (
        <View style={styles.totalCard}>
          <Text style={styles.totalLabel}>مجموع تقریبی دارایی‌ها</Text>
          <Text style={styles.totalValue}>${totalUsd.toLocaleString(undefined, { maximumFractionDigits: 2 })}</Text>
        </View>
      )}
      <FlatList
        data={rows}
        keyExtractor={(item) => item.wallet.id}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={load} />}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <Text style={styles.chainBadge}>{item.wallet.chain}</Text>
              <Text style={styles.address} numberOfLines={1}>
                {item.wallet.label || item.wallet.address}
              </Text>
            </View>
            {item.status === "error" ? (
              <Text style={styles.error}>خطا: {item.error}</Text>
            ) : item.lines.length === 0 ? (
              <Text style={styles.muted}>موجودی صفر</Text>
            ) : (
              item.lines.map((line, idx) => (
                <View key={idx} style={styles.balanceRow}>
                  <Text style={styles.symbol}>{line.symbol}</Text>
                  <View style={{ alignItems: "flex-end" }}>
                    <Text style={styles.amount}>{line.amount.toLocaleString(undefined, { maximumFractionDigits: 6 })}</Text>
                    {line.usdValue != null && (
                      <Text style={styles.usdValue}>${line.usdValue.toLocaleString(undefined, { maximumFractionDigits: 2 })}</Text>
                    )}
                  </View>
                </View>
              ))
            )}
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0b0f14" },
  empty: { padding: 24, alignItems: "center" },
  emptyText: { color: "#8a94a6", textAlign: "center" },
  card: { backgroundColor: "#141a22", margin: 8, padding: 14, borderRadius: 12 },
  cardHeader: { flexDirection: "row", alignItems: "center", marginBottom: 8, gap: 8 },
  chainBadge: { backgroundColor: "#2b6cb0", color: "white", paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6, fontSize: 12, fontWeight: "600" },
  address: { color: "#c9d1d9", flex: 1, fontSize: 12 },
  balanceRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 3 },
  symbol: { color: "#e6edf3", fontWeight: "600" },
  amount: { color: "#e6edf3" },
  muted: { color: "#8a94a6" },
  error: { color: "#f87171" },
  totalCard: { backgroundColor: "#141a22", margin: 8, marginBottom: 0, padding: 16, borderRadius: 12, alignItems: "center" },
  totalLabel: { color: "#8a94a6", fontSize: 12, marginBottom: 4 },
  totalValue: { color: "#4ade80", fontSize: 28, fontWeight: "800" },
  usdValue: { color: "#8a94a6", fontSize: 12, marginTop: 2 },
});
