import { useCallback, useState } from "react";
import { View, Text, FlatList, RefreshControl, StyleSheet } from "react-native";
import { useFocusEffect } from "expo-router";
import { getPricesBySymbol } from "../../src/lib/api/prices";
import { getStockQuotes, StockQuote } from "../../src/lib/api/stocks";
import { getApiKeys } from "../../src/lib/storage";

const CRYPTO_SYMBOLS = ["BTC", "ETH", "SOL", "BNB", "TRX", "MATIC"];
const STABLECOIN_SYMBOLS = ["USDT", "USDC", "DAI"];
const ETF_SYMBOLS = ["SPY", "QQQ", "VOO", "GLD"]; // S&P500, Nasdaq100, Vanguard S&P500, Gold

interface Row {
  section: string;
  symbol: string;
  price: number | null;
  changePercent?: number;
}

export default function MarketsScreen() {
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const keys = await getApiKeys();
      const [cryptoPrices, stableWithCryptoPrices, etfQuotes] = await Promise.all([
        getPricesBySymbol(CRYPTO_SYMBOLS, keys.coingecko),
        getPricesBySymbol(STABLECOIN_SYMBOLS, keys.coingecko),
        getStockQuotes(ETF_SYMBOLS, keys.alphaVantage).catch((e) => {
          console.warn("ETF quotes failed:", e);
          return [] as StockQuote[];
        }),
      ]);

      const cryptoRows: Row[] = CRYPTO_SYMBOLS.map((s) => ({ section: "ارزهای دیجیتال", symbol: s, price: cryptoPrices[s] ?? null }));
      const stableRows: Row[] = STABLECOIN_SYMBOLS.map((s) => ({ section: "استیبل‌کوین‌ها", symbol: s, price: stableWithCryptoPrices[s] ?? null }));
      const etfRows: Row[] = ETF_SYMBOLS.map((s) => {
        const q = etfQuotes.find((x) => x.symbol === s);
        return { section: "ETF / سهام", symbol: s, price: q?.price ?? null, changePercent: q?.changePercent };
      });

      setRows([...cryptoRows, ...stableRows, ...etfRows]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطای ناشناخته");
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const sections = Array.from(new Set(rows.map((r) => r.section)));

  return (
    <View style={styles.container}>
      {error && <Text style={styles.error}>{error}</Text>}
      <FlatList
        data={sections}
        keyExtractor={(s) => s}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={load} />}
        renderItem={({ item: section }) => (
          <View>
            <Text style={styles.sectionHeader}>{section}</Text>
            {rows
              .filter((r) => r.section === section)
              .map((r) => (
                <View key={r.symbol} style={styles.row}>
                  <Text style={styles.symbol}>{r.symbol}</Text>
                  <View style={{ alignItems: "flex-end" }}>
                    <Text style={styles.price}>{r.price != null ? `$${r.price.toLocaleString(undefined, { maximumFractionDigits: 4 })}` : "—"}</Text>
                    {r.changePercent != null && (
                      <Text style={[styles.change, r.changePercent >= 0 ? styles.up : styles.down]}>
                        {r.changePercent >= 0 ? "+" : ""}
                        {r.changePercent.toFixed(2)}%
                      </Text>
                    )}
                  </View>
                </View>
              ))}
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0b0f14" },
  sectionHeader: { color: "#8a94a6", fontWeight: "700", fontSize: 12, paddingHorizontal: 16, paddingTop: 16, paddingBottom: 6 },
  row: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingVertical: 10, borderBottomColor: "#1f2630", borderBottomWidth: 1 },
  symbol: { color: "#e6edf3", fontWeight: "700" },
  price: { color: "#e6edf3" },
  change: { fontSize: 12, marginTop: 2 },
  up: { color: "#4ade80" },
  down: { color: "#f87171" },
  error: { color: "#f87171", padding: 12 },
});
