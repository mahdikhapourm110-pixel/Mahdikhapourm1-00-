import { useCallback, useState } from "react";
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Alert } from "react-native";
import { useFocusEffect } from "expo-router";
import { addWallet, removeWallet, getWallets, getApiKeys, saveApiKeys, ChainKey, WalletEntry, ApiKeys } from "../../src/lib/storage";

const CHAINS: ChainKey[] = ["TRON", "ETH", "SOL", "BSC", "POLYGON"];

export default function SettingsScreen() {
  const [wallets, setWallets] = useState<WalletEntry[]>([]);
  const [chain, setChain] = useState<ChainKey>("TRON");
  const [address, setAddress] = useState("");
  const [label, setLabel] = useState("");
  const [apiKeys, setApiKeys] = useState<ApiKeys>({});

  const load = useCallback(async () => {
    setWallets(await getWallets());
    setApiKeys(await getApiKeys());
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  async function handleAddWallet() {
    if (!address.trim()) {
      Alert.alert("آدرس لازم است", "لطفاً یک آدرس کیف‌پول وارد کن.");
      return;
    }
    const updated = await addWallet({ chain, address: address.trim(), label: label.trim() || undefined });
    setWallets(updated);
    setAddress("");
    setLabel("");
  }

  async function handleRemove(id: string) {
    setWallets(await removeWallet(id));
  }

  async function handleSaveKeys() {
    await saveApiKeys(apiKeys);
    Alert.alert("ذخیره شد", "کلیدهای API روی گوشی ذخیره شدند.");
  }

  return (
    <FlatList
      style={styles.container}
      ListHeaderComponent={
        <View style={{ padding: 12 }}>
          <Text style={styles.section}>افزودن کیف‌پول</Text>
          <View style={styles.chainRow}>
            {CHAINS.map((c) => (
              <TouchableOpacity key={c} onPress={() => setChain(c)} style={[styles.chainChip, chain === c && styles.chainChipActive]}>
                <Text style={[styles.chainChipText, chain === c && styles.chainChipTextActive]}>{c}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <TextInput
            style={styles.input}
            placeholder="آدرس کیف‌پول"
            placeholderTextColor="#6b7280"
            value={address}
            onChangeText={setAddress}
            autoCapitalize="none"
          />
          <TextInput
            style={styles.input}
            placeholder="برچسب (اختیاری)"
            placeholderTextColor="#6b7280"
            value={label}
            onChangeText={setLabel}
          />
          <TouchableOpacity style={styles.button} onPress={handleAddWallet}>
            <Text style={styles.buttonText}>افزودن</Text>
          </TouchableOpacity>

          <Text style={[styles.section, { marginTop: 24 }]}>کلیدهای API (اختیاری، افزایش سقف درخواست)</Text>
          <TextInput
            style={styles.input}
            placeholder="TronGrid API Key"
            placeholderTextColor="#6b7280"
            value={apiKeys.tron ?? ""}
            onChangeText={(v) => setApiKeys((k) => ({ ...k, tron: v }))}
            autoCapitalize="none"
          />
          <TextInput
            style={styles.input}
            placeholder="Etherscan V2 API Key (ETH/BSC/Polygon)"
            placeholderTextColor="#6b7280"
            value={apiKeys.evmExplorer ?? ""}
            onChangeText={(v) => setApiKeys((k) => ({ ...k, evmExplorer: v }))}
            autoCapitalize="none"
          />
          <TextInput
            style={styles.input}
            placeholder="CoinGecko API Key (اختیاری)"
            placeholderTextColor="#6b7280"
            value={apiKeys.coingecko ?? ""}
            onChangeText={(v) => setApiKeys((k) => ({ ...k, coingecko: v }))}
            autoCapitalize="none"
          />
          <TextInput
            style={styles.input}
            placeholder="Alpha Vantage API Key (پشتیبان قیمت ETF)"
            placeholderTextColor="#6b7280"
            value={apiKeys.alphaVantage ?? ""}
            onChangeText={(v) => setApiKeys((k) => ({ ...k, alphaVantage: v }))}
            autoCapitalize="none"
          />
          <TouchableOpacity style={styles.button} onPress={handleSaveKeys}>
            <Text style={styles.buttonText}>ذخیره کلیدها</Text>
          </TouchableOpacity>

          <Text style={[styles.section, { marginTop: 24 }]}>کیف‌پول‌های ذخیره‌شده</Text>
        </View>
      }
      data={wallets}
      keyExtractor={(w) => w.id}
      renderItem={({ item }) => (
        <View style={styles.walletRow}>
          <Text style={styles.walletText}>
            [{item.chain}] {item.label || item.address}
          </Text>
          <TouchableOpacity onPress={() => handleRemove(item.id)}>
            <Text style={styles.remove}>حذف</Text>
          </TouchableOpacity>
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0b0f14" },
  section: { color: "#e6edf3", fontSize: 16, fontWeight: "700", marginBottom: 10 },
  chainRow: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 12 },
  chainChip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, backgroundColor: "#141a22" },
  chainChipActive: { backgroundColor: "#2b6cb0" },
  chainChipText: { color: "#8a94a6", fontSize: 12 },
  chainChipTextActive: { color: "white", fontWeight: "700" },
  input: { backgroundColor: "#141a22", color: "#e6edf3", padding: 12, borderRadius: 8, marginBottom: 10 },
  button: { backgroundColor: "#2b6cb0", padding: 12, borderRadius: 8, alignItems: "center", marginBottom: 8 },
  buttonText: { color: "white", fontWeight: "700" },
  walletRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingVertical: 10, borderBottomColor: "#1f2630", borderBottomWidth: 1 },
  walletText: { color: "#c9d1d9", flex: 1, fontSize: 12 },
  remove: { color: "#f87171", fontWeight: "700" },
});
