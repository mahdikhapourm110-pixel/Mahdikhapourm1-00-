import { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Linking, ActivityIndicator } from "react-native";
import { getIndicativeRate, buildUniswapSwapLink, SwapToken, UniswapChain } from "../../src/lib/api/uniswap";

const CHAINS: Array<{ key: "ETH" | "BSC" | "POLYGON"; label: string }> = [
  { key: "ETH", label: "Ethereum" },
  { key: "BSC", label: "BNB Chain" },
  { key: "POLYGON", label: "Polygon" },
];

export default function SwapScreen() {
  const [chain, setChain] = useState<"ETH" | "BSC" | "POLYGON">("ETH");
  const [tokenIn, setTokenIn] = useState("ETH");
  const [tokenOut, setTokenOut] = useState("USDC");
  const [amount, setAmount] = useState("1");
  const [rate, setRate] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function checkRate() {
    setLoading(true);
    setError(null);
    setRate(null);
    try {
      const inTok: SwapToken = { symbolOrAddress: tokenIn.trim(), chain };
      const outTok: SwapToken = { symbolOrAddress: tokenOut.trim(), chain };
      const r = await getIndicativeRate(inTok, outTok);
      if (r == null) {
        setError("قیمت این جفت‌توکن پیدا نشد (نماد یا آدرس قرارداد را بررسی کن).");
      } else {
        setRate(r);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطای ناشناخته");
    } finally {
      setLoading(false);
    }
  }

  function openInUniswap() {
    const inTok: SwapToken = { symbolOrAddress: tokenIn.trim(), chain };
    const outTok: SwapToken = { symbolOrAddress: tokenOut.trim(), chain };
    const link = buildUniswapSwapLink(inTok, outTok, amount.trim() || undefined);
    Linking.openURL(link);
  }

  const amountNum = Number(amount) || 0;

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.disclaimer}>
        این صفحه فقط یک نرخ تقریبی نشون می‌ده و خودش هیچ تراکنشی امضا یا ارسال نمی‌کنه. با زدن دکمهٔ آخر، سواپ واقعی داخل کیف‌پول خودت (MetaMask / Trust Wallet)
        باز و تایید می‌شه — این اپ هیچ‌وقت به کلید خصوصی تو دسترسی نداره.
      </Text>

      <Text style={styles.section}>شبکه</Text>
      <View style={styles.row}>
        {CHAINS.map((c) => (
          <TouchableOpacity key={c.key} onPress={() => setChain(c.key)} style={[styles.chip, chain === c.key && styles.chipActive]}>
            <Text style={[styles.chipText, chain === c.key && styles.chipTextActive]}>{c.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.section}>از (نماد یا آدرس قرارداد)</Text>
      <TextInput style={styles.input} value={tokenIn} onChangeText={setTokenIn} autoCapitalize="none" placeholder="ETH" placeholderTextColor="#6b7280" />

      <Text style={styles.section}>به (نماد یا آدرس قرارداد)</Text>
      <TextInput style={styles.input} value={tokenOut} onChangeText={setTokenOut} autoCapitalize="none" placeholder="USDC" placeholderTextColor="#6b7280" />

      <Text style={styles.section}>مقدار</Text>
      <TextInput style={styles.input} value={amount} onChangeText={setAmount} keyboardType="decimal-pad" />

      <TouchableOpacity style={styles.buttonSecondary} onPress={checkRate} disabled={loading}>
        {loading ? <ActivityIndicator color="white" /> : <Text style={styles.buttonText}>بررسی نرخ تقریبی</Text>}
      </TouchableOpacity>

      {error && <Text style={styles.error}>{error}</Text>}

      {rate != null && (
        <View style={styles.rateCard}>
          <Text style={styles.rateText}>
            ۱ {tokenIn} ≈ {rate.toLocaleString(undefined, { maximumFractionDigits: 6 })} {tokenOut}
          </Text>
          {amountNum > 0 && (
            <Text style={styles.rateSub}>
              {amountNum} {tokenIn} ≈ {(amountNum * rate).toLocaleString(undefined, { maximumFractionDigits: 6 })} {tokenOut}
            </Text>
          )}
        </View>
      )}

      <TouchableOpacity style={styles.buttonPrimary} onPress={openInUniswap}>
        <Text style={styles.buttonText}>باز کردن در Uniswap برای تایید و امضا</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0b0f14" },
  disclaimer: { color: "#f59e0b", fontSize: 12, marginBottom: 16, lineHeight: 18 },
  section: { color: "#e6edf3", fontWeight: "700", marginTop: 12, marginBottom: 6 },
  row: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, backgroundColor: "#141a22" },
  chipActive: { backgroundColor: "#2b6cb0" },
  chipText: { color: "#8a94a6", fontSize: 12 },
  chipTextActive: { color: "white", fontWeight: "700" },
  input: { backgroundColor: "#141a22", color: "#e6edf3", padding: 12, borderRadius: 8 },
  buttonSecondary: { backgroundColor: "#374151", padding: 12, borderRadius: 8, alignItems: "center", marginTop: 16 },
  buttonPrimary: { backgroundColor: "#ec4899", padding: 14, borderRadius: 8, alignItems: "center", marginTop: 16 },
  buttonText: { color: "white", fontWeight: "700" },
  error: { color: "#f87171", marginTop: 10 },
  rateCard: { backgroundColor: "#141a22", padding: 14, borderRadius: 12, marginTop: 14 },
  rateText: { color: "#e6edf3", fontWeight: "700", fontSize: 16 },
  rateSub: { color: "#8a94a6", marginTop: 4 },
});
