import { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, ActivityIndicator } from "react-native";
import { fetchAllTimeframes, fetchFearGreedIndex } from "../../src/lib/marketData";
import { decideScalpTrade, ScalpDecision } from "../../src/lib/strategyEngine";

const SYMBOLS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT"];

export default function TradingScreen() {
  const [symbol, setSymbol] = useState("BTCUSDT");
  const [decision, setDecision] = useState<ScalpDecision | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function runAnalysis() {
    setLoading(true);
    setError(null);
    try {
      const [candlesByTimeframe, fearGreedIndex] = await Promise.all([
        fetchAllTimeframes(symbol),
        fetchFearGreedIndex(),
      ]);
      const recentCandles = candlesByTimeframe["15m"] ?? [];
      const result = decideScalpTrade({
        candlesByTimeframe,
        sentiment: { fearGreedIndex, recentCandles },
      });
      setDecision(result);
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطای ناشناخته");
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 16 }}>
      <Text style={styles.disclaimer}>
        این بخش فقط یک سیگنال تحلیلی نمایش می‌دهد و به‌صورت خودکار سفارشی ثبت نمی‌کند. تصمیم نهایی و ریسک آن با شماست.
      </Text>

      <View style={styles.symbolRow}>
        {SYMBOLS.map((s) => (
          <TouchableOpacity key={s} onPress={() => setSymbol(s)} style={[styles.chip, symbol === s && styles.chipActive]}>
            <Text style={[styles.chipText, symbol === s && styles.chipTextActive]}>{s}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity style={styles.button} onPress={runAnalysis} disabled={loading}>
        {loading ? <ActivityIndicator color="white" /> : <Text style={styles.buttonText}>تحلیل کن</Text>}
      </TouchableOpacity>

      {error && <Text style={styles.error}>{error}</Text>}

      {decision && (
        <View style={styles.resultCard}>
          <Text style={[styles.direction, decision.direction === "BUY" ? styles.buy : decision.direction === "SELL" ? styles.sell : styles.hold]}>
            {decision.direction} — {decision.confidence.toFixed(1)}%
          </Text>
          <Text style={styles.reason}>{decision.reason}</Text>

          <Text style={styles.subSection}>سنتیمنت</Text>
          <Text style={styles.muted}>
            Fear & Greed: {decision.sentiment.fearGreedIndex} · Smart-money bias: {decision.sentiment.smartMoneyBias} (
            {decision.sentiment.smartMoneyStrength}%)
          </Text>

          <Text style={styles.subSection}>امتیاز هر تایم‌فریم</Text>
          {decision.timeframeScores.map((s) => (
            <View key={s.timeframe} style={styles.tfRow}>
              <Text style={styles.muted}>{s.timeframe}</Text>
              <Text style={styles.muted}>
                {s.direction} {s.score.toFixed(0)}% · RSI {s.rsi.toFixed(0)}
              </Text>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0b0f14" },
  disclaimer: { color: "#f59e0b", fontSize: 12, marginBottom: 16, lineHeight: 18 },
  symbolRow: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 12 },
  chip: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16, backgroundColor: "#141a22" },
  chipActive: { backgroundColor: "#2b6cb0" },
  chipText: { color: "#8a94a6", fontSize: 12 },
  chipTextActive: { color: "white", fontWeight: "700" },
  button: { backgroundColor: "#2b6cb0", padding: 14, borderRadius: 8, alignItems: "center", marginBottom: 16 },
  buttonText: { color: "white", fontWeight: "700" },
  error: { color: "#f87171", marginBottom: 12 },
  resultCard: { backgroundColor: "#141a22", padding: 16, borderRadius: 12 },
  direction: { fontSize: 20, fontWeight: "800", marginBottom: 6 },
  buy: { color: "#4ade80" },
  sell: { color: "#f87171" },
  hold: { color: "#8a94a6" },
  reason: { color: "#c9d1d9", marginBottom: 12, lineHeight: 18 },
  subSection: { color: "#e6edf3", fontWeight: "700", marginTop: 10, marginBottom: 4 },
  muted: { color: "#8a94a6", fontSize: 12 },
  tfRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 2 },
});
