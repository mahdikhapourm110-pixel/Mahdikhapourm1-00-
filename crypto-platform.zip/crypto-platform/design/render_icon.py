"""
Renders the app icon programmatically with Pillow since no SVG rasterizer
(rsvg-convert/inkscape) is available in this sandbox. Produces:
  - icon.png            1024x1024, navy background, for app.json "icon"
  - adaptive-icon.png    1024x1024, transparent bg, for Android adaptive icon foreground
  - splash-icon.png      1024x1024, transparent bg, larger glyph for splash screen
"""
import math
from PIL import Image, ImageDraw, ImageFilter

SIZE = 1024
CENTER = SIZE // 2

NAVY_DARK = (5, 6, 26, 255)
NAVY_MID = (13, 16, 48, 255)
NAVY_LIGHT = (27, 31, 75, 255)
PURPLE_LIGHT = (167, 139, 250, 255)
PURPLE_DARK = (109, 40, 217, 255)
GOLD_LIGHT = (247, 215, 116, 255)
GOLD_MID = (212, 175, 55, 255)
GOLD_DARK = (169, 126, 31, 255)


def radial_background(size):
    img = Image.new("RGBA", (size, size), NAVY_DARK)
    px = img.load()
    cx, cy = size * 0.30, size * 0.25
    max_r = size * 0.95
    for y in range(size):
        for x in range(size):
            d = math.hypot(x - cx, y - cy) / max_r
            d = min(d, 1.0)
            if d < 0.55:
                t = d / 0.55
                c = lerp_color(NAVY_LIGHT, NAVY_MID, t)
            else:
                t = (d - 0.55) / 0.45
                c = lerp_color(NAVY_MID, NAVY_DARK, t)
            px[x, y] = c
    return img


def lerp_color(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(4))


def rounded_mask(size, radius):
    mask = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(mask)
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=255)
    return mask


def draw_gradient_circle(draw_img, bbox, color_a, color_b):
    """Draws a circle filled with a diagonal gradient by layering an ellipse gradient."""
    x0, y0, x1, y1 = bbox
    w, h = x1 - x0, y1 - y0
    grad = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    gpx = grad.load()
    for y in range(h):
        for x in range(w):
            t = (x + y) / (w + h)
            gpx[x, y] = lerp_color(color_a, color_b, t)
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).ellipse([0, 0, w - 1, h - 1], fill=255)
    draw_img.paste(grad, (x0, y0), mask)


def build_icon(transparent_bg=False):
    img = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0)) if transparent_bg else radial_background(SIZE)

    # orbit rings
    ring_layer = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    rd = ImageDraw.Draw(ring_layer)
    rd.ellipse([CENTER - 330, CENTER - 330, CENTER + 330, CENTER + 330], outline=(139, 92, 246, 70), width=4)
    rd.ellipse([CENTER - 230, CENTER - 230, CENTER + 230, CENTER + 230], outline=(212, 175, 55, 80), width=4)
    img = Image.alpha_composite(img, ring_layer)

    # connecting lines + outer nodes (hexagonal layout)
    node_layer = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    nd = ImageDraw.Draw(node_layer)
    node_r = 34
    positions = []
    for i in range(6):
        angle = math.radians(60 * i - 90)
        nx = CENTER + 300 * math.cos(angle)
        ny = CENTER + 300 * math.sin(angle)
        positions.append((nx, ny))

    for (nx, ny) in positions:
        nd.line([CENTER, CENTER, nx, ny], fill=(139, 92, 246, 220), width=7)

    for (nx, ny) in positions:
        draw_gradient_circle(node_layer, [int(nx - node_r), int(ny - node_r), int(nx + node_r), int(ny + node_r)], PURPLE_LIGHT, PURPLE_DARK)

    img = Image.alpha_composite(img, node_layer)

    # glow behind the gold core
    glow_layer = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow_layer)
    gd.ellipse([CENTER - 150, CENTER - 150, CENTER + 150, CENTER + 150], fill=(212, 175, 55, 160))
    glow_layer = glow_layer.filter(ImageFilter.GaussianBlur(28))
    img = Image.alpha_composite(img, glow_layer)

    # gold core
    core_layer = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    core_r = 108
    draw_gradient_circle(core_layer, [CENTER - core_r, CENTER - core_r, CENTER + core_r, CENTER + core_r], GOLD_LIGHT, GOLD_DARK)
    img = Image.alpha_composite(img, core_layer)

    # stylized "C" glyph cut into the core
    glyph_layer = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    glyph_mask = Image.new("L", (SIZE, SIZE), 0)
    gm = ImageDraw.Draw(glyph_mask)
    gm.arc([CENTER - 62, CENTER - 62, CENTER + 62, CENTER + 62], start=-55, end=235, fill=255, width=26)
    glyph_solid = Image.new("RGBA", (SIZE, SIZE), NAVY_DARK)
    img.paste(glyph_solid, (0, 0), glyph_mask)

    return img


def rounded_corners(img, radius):
    mask = rounded_mask(SIZE, radius)
    out = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    out.paste(img, (0, 0), mask)
    return out


if __name__ == "__main__":
    icon = build_icon(transparent_bg=False)
    icon = rounded_corners(icon, radius=220)
    icon.save("icon.png")

    adaptive = build_icon(transparent_bg=True)
    adaptive.save("adaptive-icon.png")

    splash = build_icon(transparent_bg=True)
    splash.save("splash-icon.png")

    print("done")
