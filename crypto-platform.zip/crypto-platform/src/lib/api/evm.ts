/**
 * EVM balance fetcher for ETH, BSC, and Polygon.
 * Native balance: public JSON-RPC (no key needed).
 * ERC-20/BEP-20 token balances: explorer API (Etherscan/BscScan/PolygonScan
 * unified V2 API) — needs a free API key for reliable use; without one,
 * only native balance is returned.
 */

export type EvmChain = "ETH" | "BSC" | "POLYGON";

const PUBLIC_RPC: Record<EvmChain, string> = {
  ETH: "https://eth.llamarpc.com",
  BSC: "https://bsc-dataseed.binance.org",
  POLYGON: "https://polygon-rpc.com",
};

// Etherscan's V2 API now serves ETH/BSC/Polygon/etc from one endpoint,
// selected via chainid. https://docs.etherscan.io/etherscan-v2
const EXPLORER_V2_BASE = "https://api.etherscan.io/v2/api";
const CHAIN_ID: Record<EvmChain, number> = {
  ETH: 1,
  BSC: 56,
  POLYGON: 137,
};

const NATIVE_SYMBOL: Record<EvmChain, string> = {
  ETH: "ETH",
  BSC: "BNB",
  POLYGON: "MATIC",
};

export interface EvmTokenBalance {
  symbol: string;
  name: string;
  amount: number;
  contractAddress: string;
}

export interface EvmAccountBalances {
  chain: EvmChain;
  address: string;
  native: number;
  nativeSymbol: string;
  tokens: EvmTokenBalance[];
}

async function rpcCall(chain: EvmChain, method: string, params: unknown[]) {
  const res = await fetch(PUBLIC_RPC[chain], {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
  });
  if (!res.ok) throw new Error(`RPC request failed (${res.status}) on ${chain}`);
  const json = await res.json();
  if (json.error) throw new Error(`RPC error on ${chain}: ${json.error.message}`);
  return json.result;
}

/** Native coin balance (ETH/BNB/MATIC) — no API key required. */
export async function getEvmNativeBalance(chain: EvmChain, address: string): Promise<number> {
  const hexBalance = await rpcCall(chain, "eth_getBalance", [address, "latest"]);
  return Number(BigInt(hexBalance)) / 1e18;
}

/**
 * ERC-20 / BEP-20 token balances via the explorer API. Requires an API key
 * (get one free at etherscan.io — the same key works across chains on V2).
 * Returns an empty array if no key is provided.
 */
export async function getEvmTokenBalances(
  chain: EvmChain,
  address: string,
  apiKey?: string
): Promise<EvmTokenBalance[]> {
  if (!apiKey) return [];

  const url = `${EXPLORER_V2_BASE}?chainid=${CHAIN_ID[chain]}&module=account&action=tokentx&address=${address}&sort=desc&apikey=${apiKey}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Explorer request failed (${res.status}) on ${chain}`);
  const json = await res.json();
  if (json.status !== "1" || !Array.isArray(json.result)) return [];

  // Derive the current unique token contract list from recent transfers,
  // then read each contract's live balance on-chain.
  const seen = new Map<string, { symbol: string; name: string; decimals: number }>();
  for (const tx of json.result) {
    if (!seen.has(tx.contractAddress)) {
      seen.set(tx.contractAddress, {
        symbol: tx.tokenSymbol,
        name: tx.tokenName,
        decimals: Number(tx.tokenDecimal) || 18,
      });
    }
  }

  const balances: EvmTokenBalance[] = [];
  for (const [contractAddress, meta] of seen) {
    try {
      const raw = await callBalanceOf(chain, contractAddress, address);
      const amount = Number(raw) / 10 ** meta.decimals;
      if (amount > 0) {
        balances.push({ symbol: meta.symbol, name: meta.name, amount, contractAddress });
      }
    } catch {
      // Skip tokens whose balanceOf call fails (e.g. non-standard contracts).
    }
  }
  return balances;
}

/** Raw eth_call to a token's balanceOf(address) function. */
async function callBalanceOf(chain: EvmChain, contractAddress: string, holder: string): Promise<bigint> {
  const selector = "0x70a08231"; // balanceOf(address)
  const paddedHolder = holder.replace("0x", "").padStart(64, "0");
  const data = selector + paddedHolder;
  const result = await rpcCall(chain, "eth_call", [{ to: contractAddress, data }, "latest"]);
  return BigInt(result);
}

export async function getEvmBalances(chain: EvmChain, address: string, explorerApiKey?: string): Promise<EvmAccountBalances> {
  const [native, tokens] = await Promise.all([
    getEvmNativeBalance(chain, address),
    getEvmTokenBalances(chain, address, explorerApiKey),
  ]);
  return { chain, address, native, nativeSymbol: NATIVE_SYMBOL[chain], tokens };
}
