/**
 * USD price lookups via CoinGecko's public API (no key needed for the
 * free tier; heavy use may get rate-limited — pass a demo/pro key via
 * `apiKey` if the user has one).
 */

const COINGECKO_BASE = "https://api.coingecko.com/api/v3";

/** Static symbol -> CoinGecko id map for the native coins / common stablecoins we already show. */
export const SYMBOL_TO_COINGECKO_ID: Record<string, string> = {
  BTC: "bitcoin",
  ETH: "ethereum",
  TRX: "tron",
  SOL: "solana",
  BNB: "binancecoin",
  MATIC: "matic-network",
  POL: "polygon-ecosystem-token",
  USDT: "tether",
  USDC: "usd-coin",
  DAI: "dai",
  BUSD: "binance-usd",
  TUSD: "true-usd",
};

/** CoinGecko's "platform" id per chain, used for contract-address lookups. */
const CHAIN_TO_PLATFORM: Record<string, string> = {
  ETH: "ethereum",
  BSC: "binance-smart-chain",
  POLYGON: "polygon-pos",
};

function authHeader(apiKey?: string): Record<string, string> {
  return apiKey ? { "x-cg-demo-api-key": apiKey } : {};
}

/** Prices for known symbols (native coins + common stablecoins). Unknown symbols are skipped. */
export async function getPricesBySymbol(symbols: string[], apiKey?: string): Promise<Record<string, number>> {
  const ids = Array.from(
    new Set(symbols.map((s) => SYMBOL_TO_COINGECKO_ID[s.toUpperCase()]).filter((id): id is string => Boolean(id)))
  );
  if (ids.length === 0) return {};

  const url = `${COINGECKO_BASE}/simple/price?ids=${ids.join(",")}&vs_currencies=usd`;
  const res = await fetch(url, { headers: authHeader(apiKey) });
  if (!res.ok) throw new Error(`CoinGecko price request failed (${res.status})`);
  const json = await res.json();

  const bySymbol: Record<string, number> = {};
  for (const [symbol, id] of Object.entries(SYMBOL_TO_COINGECKO_ID)) {
    if (json[id]?.usd != null) bySymbol[symbol] = json[id].usd;
  }
  return bySymbol;
}

/** Prices for arbitrary ERC-20/BEP-20 tokens by contract address (covers tokens not in the static map). */
export async function getPricesByContract(
  chain: "ETH" | "BSC" | "POLYGON",
  contractAddresses: string[],
  apiKey?: string
): Promise<Record<string, number>> {
  const platform = CHAIN_TO_PLATFORM[chain];
  if (!platform || contractAddresses.length === 0) return {};

  const addrs = contractAddresses.map((a) => a.toLowerCase()).join(",");
  const url = `${COINGECKO_BASE}/simple/token_price/${platform}?contract_addresses=${addrs}&vs_currencies=usd`;
  const res = await fetch(url, { headers: authHeader(apiKey) });
  if (!res.ok) throw new Error(`CoinGecko token price request failed (${res.status})`);
  const json = await res.json();

  const byAddress: Record<string, number> = {};
  for (const addr of contractAddresses) {
    const val = json[addr.toLowerCase()]?.usd;
    if (val != null) byAddress[addr.toLowerCase()] = val;
  }
  return byAddress;
}
