/**
 * Solana balance fetcher using the public JSON-RPC endpoint.
 * No API key required (rate-limited); swap PUBLIC_RPC for a private
 * RPC provider (Helius, QuickNode, etc.) for production reliability.
 */

const PUBLIC_RPC = "https://api.mainnet-beta.solana.com";

export interface SolTokenBalance {
  mint: string;
  amount: number;
}

export interface SolAccountBalances {
  address: string;
  sol: number;
  tokens: SolTokenBalance[];
}

async function rpcCall(method: string, params: unknown[]) {
  const res = await fetch(PUBLIC_RPC, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
  });
  if (!res.ok) throw new Error(`Solana RPC request failed (${res.status})`);
  const json = await res.json();
  if (json.error) throw new Error(`Solana RPC error: ${json.error.message}`);
  return json.result;
}

export async function getSolanaBalances(address: string): Promise<SolAccountBalances> {
  const [balanceResult, tokenAccounts] = await Promise.all([
    rpcCall("getBalance", [address]),
    rpcCall("getTokenAccountsByOwner", [
      address,
      { programId: "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA" },
      { encoding: "jsonParsed" },
    ]),
  ]);

  const sol = (balanceResult?.value ?? 0) / 1e9;

  const tokens: SolTokenBalance[] = (tokenAccounts?.value ?? [])
    .map((acc: any) => {
      const info = acc.account.data.parsed.info;
      return {
        mint: info.mint,
        amount: Number(info.tokenAmount.uiAmount ?? 0),
      };
    })
    .filter((t: SolTokenBalance) => t.amount > 0);

  return { address, sol, tokens };
}
