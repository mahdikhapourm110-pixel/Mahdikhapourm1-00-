/**
 * ETF / stock price lookups.
 * Primary source: Yahoo Finance's public quote endpoint (no key, but
 * unofficial — Yahoo can rate-limit or change this without notice).
 * Fallback: Alpha Vantage (needs a free API key from alphavantage.co),
 * used automatically if the Yahoo call fails and a key is provided.
 */

export interface StockQuote {
  symbol: string;
  price: number;
  currency: string;
  changePercent: number;
}

async function fetchFromYahoo(symbols: string[]): Promise<StockQuote[]> {
  const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${symbols.join(",")}`;
  const res = await fetch(url, {
    headers: { "User-Agent": "Mozilla/5.0 (Android 15; Mobile)" },
  });
  if (!res.ok) throw new Error(`Yahoo Finance request failed (${res.status})`);
  const json = await res.json();
  const results = json?.quoteResponse?.result ?? [];

  return results.map((r: any) => ({
    symbol: r.symbol,
    price: r.regularMarketPrice,
    currency: r.currency ?? "USD",
    changePercent: r.regularMarketChangePercent ?? 0,
  }));
}

async function fetchFromAlphaVantage(symbol: string, apiKey: string): Promise<StockQuote | null> {
  const url = `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${apiKey}`;
  const res = await fetch(url);
  if (!res.ok) return null;
  const json = await res.json();
  const quote = json?.["Global Quote"];
  if (!quote || !quote["05. price"]) return null;

  return {
    symbol,
    price: Number(quote["05. price"]),
    currency: "USD",
    changePercent: Number(String(quote["10. change percent"]).replace("%", "")) || 0,
  };
}

/** Fetches quotes for a list of tickers (e.g. ["SPY", "QQQ", "VOO"]). */
export async function getStockQuotes(symbols: string[], alphaVantageKey?: string): Promise<StockQuote[]> {
  try {
    return await fetchFromYahoo(symbols);
  } catch (err) {
    if (!alphaVantageKey) throw err;
    // Alpha Vantage's free tier is one symbol per request, so fetch sequentially.
    const quotes: StockQuote[] = [];
    for (const symbol of symbols) {
      const q = await fetchFromAlphaVantage(symbol, alphaVantageKey);
      if (q) quotes.push(q);
    }
    return quotes;
  }
}
