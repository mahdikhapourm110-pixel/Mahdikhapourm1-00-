/**
 * TRON balance fetcher — uses the public TronGrid REST API.
 * Works without an API key (rate-limited); pass one in for higher limits.
 * Docs: https://developers.tron.network/reference/get-account-info
 */

export interface TronTokenBalance {
  symbol: string;
  name: string;
  amount: number; // human-readable (already divided by decimals)
  contractAddress?: string; // undefined for native TRX
}

export interface TronAccountBalances {
  address: string;
  trx: number;
  tokens: TronTokenBalance[];
}

const TRONGRID_BASE = "https://api.trongrid.io";

async function tronFetch(path: string, apiKey?: string) {
  const res = await fetch(`${TRONGRID_BASE}${path}`, {
    headers: apiKey ? { "TRON-PRO-API-KEY": apiKey } : undefined,
  });
  if (!res.ok) {
    throw new Error(`TronGrid request failed (${res.status}): ${path}`);
  }
  return res.json();
}

/** Fetches native TRX balance + TRC-20 token balances for a single address. */
export async function getTronBalances(address: string, apiKey?: string): Promise<TronAccountBalances> {
  const account = await tronFetch(`/v1/accounts/${address}`, apiKey);
  const data = account?.data?.[0];

  const trx = data?.balance ? data.balance / 1_000_000 : 0; // sun -> TRX

  const tokens: TronTokenBalance[] = [];
  const trc20 = data?.trc20 as Array<Record<string, string>> | undefined;
  if (trc20) {
    for (const entry of trc20) {
      const [contractAddress, rawAmount] = Object.entries(entry)[0];
      // TronGrid doesn't return decimals here; caller can enrich via
      // getTrc20TokenInfo() below if precise decimals are needed.
      tokens.push({
        symbol: contractAddress.slice(0, 6),
        name: contractAddress,
        amount: Number(rawAmount) / 1_000_000, // assumes 6 decimals (true for USDT-TRC20); override for others
        contractAddress,
      });
    }
  }

  return { address, trx, tokens };
}

/** Optional: look up a TRC-20 token's symbol/decimals to correct the amount above. */
export async function getTrc20TokenInfo(contractAddress: string, apiKey?: string) {
  const res = await tronFetch(`/v1/contracts/${contractAddress}/tokens`, apiKey).catch(() => null);
  return res;
}
