/**
 * Uniswap integration.
 *
 * Design choice (important): this app never holds private keys and never
 * submits swap transactions itself. It shows an indicative price (from
 * CoinGecko) and then hands off to the Uniswap web app via a deep link,
 * prefilled with the chosen tokens/amount/chain. The actual swap is
 * reviewed and signed inside the user's own wallet (MetaMask / Trust
 * Wallet's in-app browser, etc.) — this app is not custodial and never
 * touches keys, which is the only safe way to wire up a real swap here.
 */

import { getPricesBySymbol, getPricesByContract } from "./prices";

export type UniswapChain = "mainnet" | "bnb" | "polygon";

const CHAIN_MAP: Record<"ETH" | "BSC" | "POLYGON", UniswapChain> = {
  ETH: "mainnet",
  BSC: "bnb",
  POLYGON: "polygon",
};

export interface SwapToken {
  /** Use "ETH" / "BNB" / "MATIC" for native, or a symbol we know, or a raw contract address. */
  symbolOrAddress: string;
  chain: "ETH" | "BSC" | "POLYGON";
}

/**
 * Indicative USD-based exchange rate between two tokens. This is an
 * estimate for display only — the real price/slippage is whatever the
 * Uniswap interface quotes at the moment the user actually swaps.
 */
export async function getIndicativeRate(tokenIn: SwapToken, tokenOut: SwapToken, apiKey?: string): Promise<number | null> {
  const priceOf = async (t: SwapToken): Promise<number | null> => {
    const isAddress = t.symbolOrAddress.startsWith("0x");
    if (!isAddress) {
      const bySymbol = await getPricesBySymbol([t.symbolOrAddress], apiKey);
      return bySymbol[t.symbolOrAddress.toUpperCase()] ?? null;
    }
    const byContract = await getPricesByContract(t.chain, [t.symbolOrAddress], apiKey);
    return byContract[t.symbolOrAddress.toLowerCase()] ?? null;
  };

  const [priceIn, priceOut] = await Promise.all([priceOf(tokenIn), priceOf(tokenOut)]);
  if (!priceIn || !priceOut) return null;
  return priceIn / priceOut; // how many tokenOut per 1 tokenIn
}

/**
 * Builds a deep link into app.uniswap.org, prefilled with the chosen
 * swap. Opening this hands control to the user's own wallet for the
 * actual signing — this app never executes the trade itself.
 */
export function buildUniswapSwapLink(tokenIn: SwapToken, tokenOut: SwapToken, amountIn?: string): string {
  const chain = CHAIN_MAP[tokenIn.chain];
  const params = new URLSearchParams({
    inputCurrency: tokenIn.symbolOrAddress,
    outputCurrency: tokenOut.symbolOrAddress,
    chain,
  });
  if (amountIn) params.set("exactField", "input"), params.set("exactAmount", amountIn);
  return `https://app.uniswap.org/swap?${params.toString()}`;
}
