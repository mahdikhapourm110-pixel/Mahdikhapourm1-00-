import { getTronBalances } from "./api/tron";
import { getEvmBalances, EvmChain } from "./api/evm";
import { getSolanaBalances } from "./api/solana";
import { getPricesBySymbol } from "./api/prices";
import { ApiKeys, WalletEntry } from "./storage";

export interface BalanceLine {
  symbol: string;
  amount: number;
  usdValue: number | null;
}

export interface WalletBalanceRow {
  wallet: WalletEntry;
  status: "ok" | "error";
  lines: BalanceLine[];
  error?: string;
}

/** Attaches a USD value to each line where we have a known price; leaves unknown ones as null. */
async function withUsdValues(lines: { symbol: string; amount: number }[], apiKey?: string): Promise<BalanceLine[]> {
  const prices = await getPricesBySymbol(
    lines.map((l) => l.symbol),
    apiKey
  ).catch(() => ({}) as Record<string, number>);
  return lines.map((l) => {
    const price = prices[l.symbol.toUpperCase()];
    return { ...l, usdValue: price != null ? price * l.amount : null };
  });
}

/** Fetches balances for one saved wallet entry, on its configured chain. */
export async function fetchWalletBalance(wallet: WalletEntry, apiKeys: ApiKeys): Promise<WalletBalanceRow> {
  try {
    if (wallet.chain === "TRON") {
      const b = await getTronBalances(wallet.address, apiKeys.tron);
      const rawLines = [{ symbol: "TRX", amount: b.trx }, ...b.tokens.map((t) => ({ symbol: t.symbol, amount: t.amount }))];
      return { wallet, status: "ok", lines: await withUsdValues(rawLines, apiKeys.coingecko) };
    }
    if (wallet.chain === "SOL") {
      const b = await getSolanaBalances(wallet.address);
      const rawLines = [{ symbol: "SOL", amount: b.sol }, ...b.tokens.map((t) => ({ symbol: t.mint.slice(0, 4), amount: t.amount }))];
      return { wallet, status: "ok", lines: await withUsdValues(rawLines, apiKeys.coingecko) };
    }
    // ETH / BSC / POLYGON share the EVM client
    const b = await getEvmBalances(wallet.chain as EvmChain, wallet.address, apiKeys.evmExplorer);
    const rawLines = [{ symbol: b.nativeSymbol, amount: b.native }, ...b.tokens.map((t) => ({ symbol: t.symbol, amount: t.amount }))];
    return { wallet, status: "ok", lines: await withUsdValues(rawLines, apiKeys.coingecko) };
  } catch (err) {
    return { wallet, status: "error", lines: [], error: err instanceof Error ? err.message : "Unknown error" };
  }
}

/** Fetches all saved wallets in parallel. */
export async function fetchAllBalances(wallets: WalletEntry[], apiKeys: ApiKeys): Promise<WalletBalanceRow[]> {
  return Promise.all(wallets.map((w) => fetchWalletBalance(w, apiKeys)));
}
