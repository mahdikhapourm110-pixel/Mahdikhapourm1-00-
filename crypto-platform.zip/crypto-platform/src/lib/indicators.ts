/**
 * Core technical indicators used by strategyEngine.ts
 * Pure functions, no side effects, no external dependencies.
 */

/** Exponential Moving Average. Returns an array aligned to the tail of `prices`. */
export function calculateEMA(prices: number[], period: number): number[] {
  if (prices.length < period) return [];
  const k = 2 / (period + 1);
  const out: number[] = [];

  // Seed the first EMA value with a simple average of the first `period` prices.
  let seed = 0;
  for (let i = 0; i < period; i++) seed += prices[i];
  seed /= period;
  out.push(seed);

  for (let i = period; i < prices.length; i++) {
    const prevEma = out[out.length - 1];
    const ema = prices[i] * k + prevEma * (1 - k);
    out.push(ema);
  }
  return out;
}

/** Relative Strength Index (Wilder's smoothing). */
export function calculateRSI(prices: number[], period = 14): number[] {
  if (prices.length < period + 1) return [];
  const gains: number[] = [];
  const losses: number[] = [];

  for (let i = 1; i < prices.length; i++) {
    const change = prices[i] - prices[i - 1];
    gains.push(Math.max(change, 0));
    losses.push(Math.max(-change, 0));
  }

  let avgGain = 0;
  let avgLoss = 0;
  for (let i = 0; i < period; i++) {
    avgGain += gains[i];
    avgLoss += losses[i];
  }
  avgGain /= period;
  avgLoss /= period;

  const out: number[] = [];
  const pushRsi = (ag: number, al: number) => {
    if (al === 0) return out.push(100);
    const rs = ag / al;
    out.push(100 - 100 / (1 + rs));
  };
  pushRsi(avgGain, avgLoss);

  for (let i = period; i < gains.length; i++) {
    avgGain = (avgGain * (period - 1) + gains[i]) / period;
    avgLoss = (avgLoss * (period - 1) + losses[i]) / period;
    pushRsi(avgGain, avgLoss);
  }
  return out;
}

export interface MACDResult {
  macdLine: number[];
  signalLine: number[];
  histogram: number[];
}

/** Standard MACD(12,26,9). */
export function calculateMACD(
  prices: number[],
  fastPeriod = 12,
  slowPeriod = 26,
  signalPeriod = 9
): MACDResult {
  const emaFast = calculateEMA(prices, fastPeriod);
  const emaSlow = calculateEMA(prices, slowPeriod);
  if (emaFast.length === 0 || emaSlow.length === 0) {
    return { macdLine: [], signalLine: [], histogram: [] };
  }

  // Align the two EMA arrays to the same tail length before subtracting.
  const offset = emaFast.length - emaSlow.length;
  const alignedFast = offset > 0 ? emaFast.slice(offset) : emaFast;
  const alignedSlow = offset < 0 ? emaSlow.slice(-offset) : emaSlow;
  const len = Math.min(alignedFast.length, alignedSlow.length);

  const macdLine: number[] = [];
  for (let i = 0; i < len; i++) {
    macdLine.push(
      alignedFast[alignedFast.length - len + i] - alignedSlow[alignedSlow.length - len + i]
    );
  }

  const signalLine = calculateEMA(macdLine, signalPeriod);
  const macdTail = macdLine.slice(macdLine.length - signalLine.length);
  const histogram = macdTail.map((v, i) => v - signalLine[i]);

  return { macdLine, signalLine, histogram };
}
