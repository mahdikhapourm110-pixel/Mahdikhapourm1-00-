import { Candle, Timeframe } from "./strategyEngine";

/** Maps our Timeframe type to Binance's kline interval strings. */
const BINANCE_INTERVAL: Record<Timeframe, string> = {
  "15m": "15m",
  "1h": "1h",
  "4h": "4h",
  "12h": "12h",
  "1d": "1d",
};

/**
 * Public candle data from Binance (no API key, no account needed).
 * `symbol` uses Binance's pair format, e.g. "BTCUSDT".
 */
export async function fetchCandles(symbol: string, timeframe: Timeframe, limit = 100): Promise<Candle[]> {
  const interval = BINANCE_INTERVAL[timeframe];
  const url = `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Binance klines request failed (${res.status}) for ${symbol} ${timeframe}`);
  const raw: any[] = await res.json();

  return raw.map((k) => ({
    time: k[0],
    open: Number(k[1]),
    high: Number(k[2]),
    low: Number(k[3]),
    close: Number(k[4]),
    volume: Number(k[5]),
  }));
}

/** Fetches candles for every timeframe the strategy engine needs, in parallel. */
export async function fetchAllTimeframes(
  symbol: string,
  timeframes: Timeframe[] = ["15m", "1h", "4h", "12h", "1d"]
): Promise<Partial<Record<Timeframe, Candle[]>>> {
  const results = await Promise.all(timeframes.map((tf) => fetchCandles(symbol, tf).then((c) => [tf, c] as const)));
  return Object.fromEntries(results);
}

/** Public Fear & Greed Index (crypto-wide, not per-symbol). No API key needed. */
export async function fetchFearGreedIndex(): Promise<number> {
  const res = await fetch("https://api.alternative.me/fng/?limit=1");
  if (!res.ok) throw new Error(`Fear & Greed request failed (${res.status})`);
  const json = await res.json();
  const value = Number(json?.data?.[0]?.value);
  return Number.isFinite(value) ? value : 50; // neutral fallback
}
