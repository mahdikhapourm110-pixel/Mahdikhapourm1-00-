/**
 * Secure on-device storage for wallet addresses and API keys.
 * Everything here stays local to the phone (expo-secure-store uses the
 * Android Keystore) — nothing is sent anywhere except the public
 * blockchain APIs the user configures.
 */
import * as SecureStore from "expo-secure-store";

export type ChainKey = "TRON" | "ETH" | "SOL" | "BSC" | "POLYGON";

export interface WalletEntry {
  id: string;
  chain: ChainKey;
  address: string;
  label?: string;
}

const WALLETS_KEY = "wallets_v1";
const API_KEYS_KEY = "api_keys_v1"; // { tron?, evmExplorer?, fearGreedProvider? }

export async function getWallets(): Promise<WalletEntry[]> {
  const raw = await SecureStore.getItemAsync(WALLETS_KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function saveWallets(wallets: WalletEntry[]): Promise<void> {
  await SecureStore.setItemAsync(WALLETS_KEY, JSON.stringify(wallets));
}

export async function addWallet(entry: Omit<WalletEntry, "id">): Promise<WalletEntry[]> {
  const wallets = await getWallets();
  const withId: WalletEntry = { ...entry, id: `${entry.chain}-${entry.address}-${Date.now()}` };
  const updated = [...wallets, withId];
  await saveWallets(updated);
  return updated;
}

export async function removeWallet(id: string): Promise<WalletEntry[]> {
  const wallets = await getWallets();
  const updated = wallets.filter((w) => w.id !== id);
  await saveWallets(updated);
  return updated;
}

export interface ApiKeys {
  tron?: string;
  evmExplorer?: string; // Etherscan V2 key, also covers BSC/Polygon
  coingecko?: string; // optional, raises CoinGecko rate limits
  alphaVantage?: string; // optional fallback for ETF/stock quotes if Yahoo fails
}

export async function getApiKeys(): Promise<ApiKeys> {
  const raw = await SecureStore.getItemAsync(API_KEYS_KEY);
  return raw ? JSON.parse(raw) : {};
}

export async function saveApiKeys(keys: ApiKeys): Promise<void> {
  await SecureStore.setItemAsync(API_KEYS_KEY, JSON.stringify(keys));
}
