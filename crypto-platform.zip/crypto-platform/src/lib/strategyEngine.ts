/**
 * Scalping Strategy Engine
 * ------------------------
 * Combines multi-timeframe indicator confluence (EMA/MA/RSI/MACD),
 * a fear-greed sentiment score, a smart-money (volume-based) proxy,
 * and a capped martingale position-sizing model.
 *
 * IMPORTANT RISK NOTE (read before enabling live trading):
 * - No combination of indicators guarantees a win rate. The 70%
 *   threshold below is a *signal confidence* cutoff, not a promised
 *   success rate.
 * - Martingale increases size after a loss. With small starting
 *   capital this can wipe the account in a handful of losing trades
 *   if uncapped. MARTINGALE_MAX_STEPS and MARTINGALE_MULTIPLIER below
 *   are hard caps — do not remove them.
 * - Always keep stopLoss, takeProfit, and trailingStop set on every
 *   trade. The bot refuses to open a trade without all three
 *   (see assertRiskParams).
 * - This engine only ever produces a signal + suggested size. It does
 *   NOT place orders itself — order execution is wired up separately
 *   behind an explicit user confirmation (see src/lib/execution.ts).
 */

import { calculateEMA, calculateRSI, calculateMACD } from "./indicators";

export type Timeframe = "15m" | "1h" | "4h" | "12h" | "1d";
export type TradeDirection = "BUY" | "SELL" | "HOLD";

export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

// ---------------------------------------------------------------------------
// 1. Per-timeframe indicator confluence score (0-100)
// ---------------------------------------------------------------------------

export interface TimeframeScore {
  timeframe: Timeframe;
  direction: TradeDirection;
  score: number; // 0-100 confidence for `direction`
  rsi: number;
  emaFast: number;
  emaSlow: number;
  maFast: number;
  maSlow: number;
  macdHistogram: number;
}

function calculateSMA(prices: number[], period: number): number[] {
  if (prices.length < period) return [];
  const out: number[] = [];
  for (let i = period - 1; i < prices.length; i++) {
    let sum = 0;
    for (let j = i - period + 1; j <= i; j++) sum += prices[j];
    out.push(sum / period);
  }
  return out;
}

export function scoreTimeframe(candles: Candle[], timeframe: Timeframe): TimeframeScore | null {
  const closes = candles.map((c) => c.close);
  if (closes.length < 30) return null;

  const rsiArr = calculateRSI(closes, 14);
  const emaFastArr = calculateEMA(closes, 9);
  const emaSlowArr = calculateEMA(closes, 21);
  const maFastArr = calculateSMA(closes, 10);
  const maSlowArr = calculateSMA(closes, 30);
  const macd = calculateMACD(closes);

  if (rsiArr.length === 0 || emaFastArr.length < 2 || emaSlowArr.length < 2) return null;

  const rsi = rsiArr.at(-1)!;
  const emaFast = emaFastArr.at(-1)!;
  const emaSlow = emaSlowArr.at(-1)!;
  const prevEmaFast = emaFastArr.at(-2)!;
  const prevEmaSlow = emaSlowArr.at(-2)!;
  const maFast = maFastArr.at(-1) ?? emaFast;
  const maSlow = maSlowArr.at(-1) ?? emaSlow;
  const histogram = macd.histogram.at(-1) ?? 0;
  const prevHistogram = macd.histogram.at(-2) ?? histogram;

  let buy = 0;
  let sell = 0;

  // RSI: oversold/overbought
  if (rsi < 30) buy += 25;
  else if (rsi < 45) buy += 12;
  if (rsi > 70) sell += 25;
  else if (rsi > 55) sell += 12;

  // EMA crossover (fast/slow)
  const emaCrossUp = prevEmaFast <= prevEmaSlow && emaFast > emaSlow;
  const emaCrossDown = prevEmaFast >= prevEmaSlow && emaFast < emaSlow;
  if (emaCrossUp) buy += 25;
  else if (emaFast > emaSlow) buy += 10;
  if (emaCrossDown) sell += 25;
  else if (emaFast < emaSlow) sell += 10;

  // MA trend confirmation
  if (maFast > maSlow) buy += 10;
  if (maFast < maSlow) sell += 10;

  // MACD histogram crossover
  const macdCrossUp = prevHistogram <= 0 && histogram > 0;
  const macdCrossDown = prevHistogram >= 0 && histogram < 0;
  if (macdCrossUp) buy += 25;
  else if (histogram > 0) buy += 12;
  if (macdCrossDown) sell += 25;
  else if (histogram < 0) sell += 12;

  buy = Math.min(buy, 100);
  sell = Math.min(sell, 100);

  const direction: TradeDirection = buy === sell ? "HOLD" : buy > sell ? "BUY" : "SELL";
  const score = direction === "HOLD" ? 0 : Math.max(buy, sell);

  return { timeframe, direction, score, rsi, emaFast, emaSlow, maFast, maSlow, macdHistogram: histogram };
}

// ---------------------------------------------------------------------------
// 2. Sentiment: Fear & Greed + a simple "smart money" volume proxy
// ---------------------------------------------------------------------------

export interface SentimentInput {
  fearGreedIndex: number; // 0 (extreme fear) - 100 (extreme greed), from an external API
  recentCandles: Candle[]; // used for the volume proxy
}

export interface SentimentResult {
  fearGreedIndex: number;
  smartMoneyBias: TradeDirection; // volume-weighted price direction proxy
  smartMoneyStrength: number; // 0-100
}

/**
 * Smart-money proxy: looks at whether recent up-candles carry more volume
 * than down-candles (accumulation) or vice versa (distribution). This is a
 * simplification — real smart-money tracking needs order-book/on-chain data.
 */
export function analyzeSentiment({ fearGreedIndex, recentCandles }: SentimentInput): SentimentResult {
  const last = recentCandles.slice(-20);
  let upVolume = 0;
  let downVolume = 0;
  for (const c of last) {
    if (c.close >= c.open) upVolume += c.volume;
    else downVolume += c.volume;
  }
  const total = upVolume + downVolume || 1;
  const upRatio = upVolume / total;
  const smartMoneyBias: TradeDirection = upRatio > 0.55 ? "BUY" : upRatio < 0.45 ? "SELL" : "HOLD";
  const smartMoneyStrength = Math.round(Math.abs(upRatio - 0.5) * 200); // 0-100

  return { fearGreedIndex, smartMoneyBias, smartMoneyStrength };
}

// ---------------------------------------------------------------------------
// 3. Multi-timeframe confluence -> final scalping decision
// ---------------------------------------------------------------------------

export interface ScalpDecisionInput {
  candlesByTimeframe: Partial<Record<Timeframe, Candle[]>>;
  sentiment: SentimentInput;
  entryThreshold?: number; // default 70
}

export interface ScalpDecision {
  direction: TradeDirection;
  confidence: number; // 0-100
  timeframeScores: TimeframeScore[];
  sentiment: SentimentResult;
  reason: string;
}

// Shorter timeframes matter more for a 0-2h scalp, but we still require
// the higher timeframes not to be strongly against the trade.
const TIMEFRAME_WEIGHTS: Record<Timeframe, number> = {
  "15m": 0.35,
  "1h": 0.3,
  "4h": 0.2,
  "12h": 0.1,
  "1d": 0.05,
};

export function decideScalpTrade({
  candlesByTimeframe,
  sentiment,
  entryThreshold = 70,
}: ScalpDecisionInput): ScalpDecision {
  const timeframeScores: TimeframeScore[] = [];
  for (const tf of Object.keys(candlesByTimeframe) as Timeframe[]) {
    const candles = candlesByTimeframe[tf];
    if (!candles) continue;
    const s = scoreTimeframe(candles, tf);
    if (s) timeframeScores.push(s);
  }

  if (timeframeScores.length === 0) {
    return {
      direction: "HOLD",
      confidence: 0,
      timeframeScores,
      sentiment: analyzeSentiment(sentiment),
      reason: "Not enough candle data across timeframes.",
    };
  }

  let buyWeighted = 0;
  let sellWeighted = 0;
  let weightUsed = 0;
  for (const s of timeframeScores) {
    const w = TIMEFRAME_WEIGHTS[s.timeframe] ?? 0.1;
    weightUsed += w;
    if (s.direction === "BUY") buyWeighted += s.score * w;
    if (s.direction === "SELL") sellWeighted += s.score * w;
  }
  buyWeighted = weightUsed > 0 ? buyWeighted / weightUsed : 0;
  sellWeighted = weightUsed > 0 ? sellWeighted / weightUsed : 0;

  const sentimentResult = analyzeSentiment(sentiment);

  // Sentiment nudges confidence: extreme fear favors BUY setups (contrarian),
  // extreme greed favors SELL setups; smart-money bias must agree with the
  // technical direction to add its bonus, otherwise it's ignored.
  let buyBonus = 0;
  let sellBonus = 0;
  if (sentimentResult.fearGreedIndex <= 25) buyBonus += 8;
  if (sentimentResult.fearGreedIndex >= 75) sellBonus += 8;
  if (sentimentResult.smartMoneyBias === "BUY") buyBonus += sentimentResult.smartMoneyStrength * 0.15;
  if (sentimentResult.smartMoneyBias === "SELL") sellBonus += sentimentResult.smartMoneyStrength * 0.15;

  const buyFinal = Math.min(100, buyWeighted + buyBonus);
  const sellFinal = Math.min(100, sellWeighted + sellBonus);

  let direction: TradeDirection = "HOLD";
  let confidence = 0;
  if (buyFinal >= entryThreshold && buyFinal > sellFinal) {
    direction = "BUY";
    confidence = buyFinal;
  } else if (sellFinal >= entryThreshold && sellFinal > buyFinal) {
    direction = "SELL";
    confidence = sellFinal;
  }

  const reason =
    direction === "HOLD"
      ? `No side reached the ${entryThreshold}% confidence threshold (BUY ${buyFinal.toFixed(1)}%, SELL ${sellFinal.toFixed(1)}%).`
      : `${direction} confidence ${confidence.toFixed(1)}% across ${timeframeScores.length} timeframe(s), sentiment ${
          sentimentResult.fearGreedIndex <= 25 ? "fearful" : sentimentResult.fearGreedIndex >= 75 ? "greedy" : "neutral"
        }.`;

  return { direction, confidence, timeframeScores, sentiment: sentimentResult, reason };
}

// ---------------------------------------------------------------------------
// 4. Capped martingale position sizing
// ---------------------------------------------------------------------------

/** Hard safety caps — do not remove. */
export const MARTINGALE_MAX_STEPS = 3;
export const MARTINGALE_MULTIPLIER = 1.5; // size grows 1.5x per consecutive loss, not 2x

export interface MartingaleState {
  consecutiveLosses: number; // 0 = first trade at base size
}

export interface PositionSizeResult {
  sizeUsd: number;
  step: number;
  cappedByMaxSteps: boolean;
}

/**
 * Computes the next trade size given a base size and how many consecutive
 * losses just occurred. Growth is capped at MARTINGALE_MAX_STEPS — beyond
 * that it resets to base size rather than continuing to escalate.
 */
export function computeMartingaleSize(baseSizeUsd: number, state: MartingaleState): PositionSizeResult {
  const step = Math.min(state.consecutiveLosses, MARTINGALE_MAX_STEPS);
  const cappedByMaxSteps = state.consecutiveLosses >= MARTINGALE_MAX_STEPS;
  const effectiveStep = cappedByMaxSteps ? 0 : step; // reset after max steps
  const sizeUsd = baseSizeUsd * Math.pow(MARTINGALE_MULTIPLIER, effectiveStep);
  return { sizeUsd: Math.round(sizeUsd * 100) / 100, step: effectiveStep, cappedByMaxSteps };
}

// ---------------------------------------------------------------------------
// 5. Trade-frequency limiter (5-10 trades/hour) + mandatory risk fields
// ---------------------------------------------------------------------------

export interface FrequencyLimiterState {
  openedTimestamps: number[]; // ms epoch of trades opened, pruned to last hour
}

export interface RiskParams {
  stopLossPercent: number;
  takeProfitPercent: number;
  trailingStopPercent: number;
}

export function canOpenNewTrade(state: FrequencyLimiterState, maxPerHour: number, now = Date.now()): boolean {
  const oneHourAgo = now - 60 * 60 * 1000;
  const recent = state.openedTimestamps.filter((t) => t > oneHourAgo);
  return recent.length < maxPerHour;
}

/** Throws if any required risk field is missing — every trade must set all three. */
export function assertRiskParams(risk: Partial<RiskParams>): asserts risk is RiskParams {
  if (risk.stopLossPercent == null || risk.takeProfitPercent == null || risk.trailingStopPercent == null) {
    throw new Error("Refusing to open trade: stopLoss, takeProfit, and trailingStop are all required.");
  }
}
