/**
 * Shared design system for the app: navy / purple / gold palette.
 * Import `colors`, `gradients`, and the small style helpers below instead
 * of hardcoding hex values in each screen, so the look stays consistent.
 */

export const colors = {
  // Navy (backgrounds)
  navyDarkest: "#05061a",
  navyDark: "#0d1030",
  navy: "#131736",
  navyLight: "#1b1f4b",
  navyCard: "#161a3d",
  navyBorder: "#262b5c",

  // Purple (accents, links, secondary actions)
  purpleLight: "#a78bfa",
  purple: "#8b5cf6",
  purpleDark: "#6d28d9",

  // Gold (primary actions, highlights, positive values)
  goldLight: "#f7d774",
  gold: "#d4af37",
  goldDark: "#a97e1f",

  // Feedback
  positive: "#4ade80",
  negative: "#f87171",
  warning: "#f59e0b",
  textPrimary: "#f1f2fb",
  textSecondary: "#9aa1c9",
  textMuted: "#6b7099",
};

/** Gradient color stops for expo-linear-gradient, keyed by purpose. */
export const gradients = {
  header: [colors.navyLight, colors.navyDark] as const,
  gold: [colors.goldLight, colors.gold, colors.goldDark] as const,
  purple: [colors.purpleLight, colors.purpleDark] as const,
  screenBg: [colors.navy, colors.navyDarkest] as const,
};

export const radius = {
  sm: 10,
  md: 16,
  lg: 22,
  pill: 999,
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
};

/** Emoji glyphs for the recurring action buttons across the app. */
export const actionIcons = {
  send: "📤",
  receive: "📥",
  transfer: "🔁",
  swap: "🔄",
  connect: "🔗",
  add: "➕",
  remove: "🗑️",
  refresh: "🔃",
  settings: "⚙️",
  key: "🔑",
  wallet: "👛",
  chart: "📈",
  bell: "🔔",
  lock: "🔒",
  scan: "📷",
  copy: "📋",
  check: "✅",
  warning: "⚠️",
};

export const shadow = {
  card: {
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 6,
  },
  glow: {
    shadowColor: colors.gold,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.45,
    shadowRadius: 16,
    elevation: 8,
  },
};
